package Practica2;

import javax.swing.JTextArea;

public class Cliente extends Thread{
	
	Surtidor s;
	RecargaSurtidor r;
	JTextArea t;
	
	public Cliente(Surtidor s, RecargaSurtidor r, JTextArea t) {
		this.s = s;
		this.r = r;
		this.t = t;
	}
	
	@Override
	public void run() {
		while(true) {
			while(Integer.parseInt(s.lblGas.getText())<1) {
				t.append("No queda gasolina, esperando a la recarga...\n");
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			try {
				sleep((long) (Math.random()*3));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			int cantidad = (int) (Math.random()*1000); 
			boolean sobras = s.cambiaGas(-cantidad);
			while(sobras) {
				t.append("No queda suficiente gasolina, esperando a la recarga...\n");
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				sobras = s.cambiaGas(-cantidad);
			}
			t.append("Se han gastado "+cantidad+" litros de gasolina...\n");
			s.lblGasCons.setText(""+Integer.parseInt(s.lblGasCons.getText())+cantidad);
		}
	}
}
