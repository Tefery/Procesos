package Practica2;

import java.awt.Dimension;

public class SurtidorLogico {
	
	public static void main(String[] args) {
		Surtidor surtidor = new Surtidor();
		surtidor.setSize(new Dimension(533,401));
		surtidor.setLocation(350,100);
		surtidor.setVisible(true);
		RecargaSurtidor recarga = new RecargaSurtidor(surtidor);
		recarga.setSize(new Dimension(533,70));
		recarga.setLocation(surtidor.getLocation().x,(int) (surtidor.getLocation().y+surtidor.getSize().getHeight()+15));
		recarga.setVisible(true);
		
		Cliente cliente1 = new Cliente(surtidor, recarga, surtidor.txtPaneCli1);
		Cliente cliente2 = new Cliente(surtidor, recarga, surtidor.txtPaneCli2);
		
		cliente1.start();
		cliente2.start();
	}
}
