
package juegoTresNumeros;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Jugador extends Thread {
	private ControlJuego inforJue;
	int turno;
	String nomJugador;

	public int getTurno() {
		return turno;
	}

	@Override
	public void run() {
		while (!inforJue.isFinJuego()) {

			inforJue.jugar();
			try {
				Thread.sleep(10);
			} catch (InterruptedException ex) {
				Logger.getLogger(Jugador.class.getName()).log(Level.SEVERE, null, ex);
			}

		}

	}

	Jugador(ControlJuego inf, int tur) {
		inforJue = inf;
		turno = tur;

		Scanner pedir = new Scanner(System.in);
		System.out.print("\n\tIndique su nombre: ");
		nomJugador = pedir.nextLine();
		this.setName(nomJugador);
		pedir.close();
	}

}
