package juegoTresNumeros;


import java.util.ArrayList;
import java.util.Scanner;


public class Juego {

    public static void main(String[] args) {
        int numJug;
        Jugador jugador;

        ArrayList<Jugador> listaJugadores = new ArrayList<Jugador>();
        Scanner pedir = new Scanner(System.in);

        System.out.print("\n\tIndique cuantos jugadores van a participar: ");
        numJug = pedir.nextInt();
        ControlJuego inforJuego = new ControlJuego(numJug);
    
        for (int posJu = 1; posJu <= numJug; posJu++) {
            jugador = new Jugador(inforJuego, posJu);
            listaJugadores.add(jugador);

        }
        Arbitro arbitro=new Arbitro(inforJuego);
        arbitro.start();
        
        System.out.println("holaaaaaaaaaaaaaaaa");
      
          for (int posJu = 0; posJu <numJug; posJu++) {
              jugador=(Jugador)listaJugadores.get(posJu);
              jugador.start();
          }
        pedir.close();
    }
    
   

}
