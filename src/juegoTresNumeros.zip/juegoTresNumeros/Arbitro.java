

package juegoTresNumeros;





public class Arbitro extends Thread{
    ControlJuego infJ;
    Arbitro(ControlJuego infJu)
    {
        infJ=infJu;
        
    }
    
    public void run()
    {
       infJ.fijarTurno(); 
        for(int pos=0;pos<infJ.getCantNumAcertar();pos++)
        {
        
        infJ.numAdivinar();
        }
        
        
    }

}
