package juegoTresNumeros;


import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControlJuego {

    int numJugadores;
    int turnoJuego;
   
    int numAdivinar;
    private boolean acertado=true;//saber si el n�mero actual ha sido acertado
    boolean finJuego;
    int numAcertados;
    int cantNumAcertar;
    private final int CANTNUMACERTAR=3;

    public int getCantNumAcertar() {
        return cantNumAcertar;
    }

    ControlJuego(int numJ) {
        
        numJugadores = numJ;
    }

    public boolean isAcertado() {
        return acertado;
    }

    public boolean isFinJuego() {
        return finJuego;
    }

    synchronized void jugar()////
    {
        Jugador jugadorActual = (Jugador) Thread.currentThread();
        int turnoJugadorActual = jugadorActual.getTurno();

        while (acertado&&turnoJugadorActual != turnoJuego && !finJuego) {
            System.out.println("\t\t\tTe vamos a parar " + jugadorActual.getName() + ". Todav�a no puedes jugar.");
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(ControlJuego.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("\t\t\tAlguien ha jugado y te ha levantado (estabas parado), para que jueges. Vamos a ver si te toca a ti (" + jugadorActual.getName() + ").");
            
        }

        if (!acertado&&!finJuego&& turnoJugadorActual == turnoJuego) {
            String nomJugadorActual = Thread.currentThread().getName();
            Scanner pedir = new Scanner(System.in);
            System.out.print("\n\tIndique el n�mero " + nomJugadorActual + " que cree que es: ");
            int numIndJugador = pedir.nextInt();
            if (numIndJugador == numAdivinar) {
                System.out.println("Muy bien. Has acertado.");
                acertado = true;
                numAcertados++;
                System.out.println("Ya se han acertado "+ numAcertados);
                if(numAcertados==CANTNUMACERTAR)
                {
                    System.out.println("Ya se han acertado todos. FIN DEL JUEGO");
                    finJuego=true;
                }
              

            } else {

                System.out.println("Lo siento, no es el n�mero " + numIndJugador);
            }
            if (turnoJuego == numJugadores) {
                turnoJuego = 1;
            } else {
                turnoJuego++;
            }
            notifyAll();
            pedir.close();
        } else if (acertado) {
            
        }/* else {
            System.out.println(jugadorActual.getName() + " no es tu turno. El turno tuyo es  " + turnoJugadorActual + " y el toca a " + turnoJuego);
        }*/
    }

    void fijarTurno() {
        turnoJuego = (int) (Math.random() * numJugadores + 1);
        System.out.println("El turno, por el que empieza el juego es "+ turnoJuego);
    }

   synchronized void numAdivinar() {

        while (!acertado) {
            System.out.println("\n\t\tSe�or arbitro. Te voy a parar porque el n�mero anterior todav�a no ha sido acertado.");
            System.out.println("\t\tNo puede poner el siguiente n�mero.");
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(ControlJuego.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("\t\tAl arbitro le han despertado. Vamos a ver si puede poner el siguiente n�mero.");

        }
        numAdivinar = (int) (Math.random() * 1000 + 1);
        System.out.println("El n�mero que hay que adivinar es " + numAdivinar);
        acertado=false;
        notifyAll();
    }

}
